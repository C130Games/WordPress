# theme-unit-test
Theme Unit Test

For instructions on how to use the Theme Unit Test please see
https://codex.wordpress.org/Theme_Unit_Test
